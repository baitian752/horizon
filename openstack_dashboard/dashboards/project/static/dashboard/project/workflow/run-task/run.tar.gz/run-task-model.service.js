/**
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

(function () {
    'use strict';
  
    angular
      .module('horizon.dashboard.project.workflow.run-task')
      .factory('RunTaskModel', RunTaskModel);
  
    function RunTaskModel() {
  
      var model = {
  
        newInstanceSpec: {},
  
        initialize: initialize,
        createInstance: createInstance
      };
  
      function initializeNewInstanceSpec() {
  
        model.newInstanceSpec = {

          name: null,
          virtualization: null,
          cpu: null,
          ram: null,
          disk: null,
          job: null,
          
          estimated_time_of_execution: null,
          execution_frequency: null,
          main_job: null,
          require_hardware: null,
          priority_coef: null,
          
        };
      }
  
      function initialize() {

        initializeNewInstanceSpec();
        
        model.newInstanceSpec.estimated_time_of_execution = -1;
        model.newInstanceSpec.execution_frequency = -1;
        model.newInstanceSpec.main_job = "Unspecified";
        model.newInstanceSpec.require_hardware = "No";
        model.newInstanceSpec.priority = 1;
        model.newInstanceSpec.virtualization = model.virtualization[0];
      }
  
      function createInstance() {
  
        var finalSpec = angular.copy(model.newInstanceSpec);
        console.log(JSON.stringify(finalSpec));
        alert(2333);
  
        // if (finalSpec.virtualization === "Virtual Machine") {
        //   return novaAPI.createServer(finalSpec).then(successMessage);
        // } else {
        //   return zunAPI.createContainer(
        //             {
        //               "name": finalSpec.meta.task_name,
        //               "image": "ubuntu",
        //               "image_driver": "docker",
        //               "command": finalSpec.user_data,
        //               "run": true,
        //               "cpu": finalSpec.vcpus,
        //               "memory": finalSpec.ram,
        //               "auto_heal": false,
        //               "mounts": [],
        //               "security_groups": [
        //                   "default"
        //               ],
        //               "interactive": true,
        //               "hints": {},
        //               // "disk": finalSpec.disk,
        //               "nets": [],
        //             }
        //          ).then(function() {
        //             var numberInstances = model.newInstanceSpec.instance_count;
        //             var message = ngettext('Scheduled creation of %s container.',
        //                                   'Scheduled creation of %s containers.',
        //                                   numberInstances);
        //             toast.add('info', interpolate(message, [numberInstances]));
        //         });
        }
      }
  
      function successMessage() {
        var numberInstances = model.newInstanceSpec.instance_count;
        var message = ngettext('Scheduled creation of %s instance.',
                               'Scheduled creation of %s instances.',
                               numberInstances);
        toast.add('info', interpolate(message, [numberInstances]));
      }
  
      function setFlavorID() {
        var vcpus = model.newInstanceSpec.vcpus;
        var ram = model.newInstanceSpec.ram;
        var disk = model.newInstanceSpec.disk;
        $.ajax({
          async: false,
          type: "GET",
          url: "/api/nova/flavors/",
          contentType: "application/json;charset=UTF-8",
          success: function (response) {
            var flavors = response.items;
            for (var i = 0; i < flavors.length; i++) {
              if (flavors[i].vcpus >= vcpus && flavors[i].ram >= ram && flavors[i].disk >= disk) {
                model.newInstanceSpec.flavor_id = flavors[i].id;
                break;
              }
            }
          },
          error: function (e) {
            console.log(e);
          }
        });
      }
  
      function setInstanceImage() {
        $.ajax({
          async: false,
          type: "GET",
          url: "/api/glance/images/",
          contentType: "application/json;charset=UTF-8",
          success: function (response) {
            var images = response.items;
            model.newInstanceSpec.source_id = images[0].id;
            model.newInstanceSpec.name = images[0].name;
            for (var image of images) {
              if (image.name.toLowerCase().indexOf("ubuntu") !== -1) {
                model.newInstanceSpec.source_id = image.id;
                model.newInstanceSpec.name = image.name;
                break;
              }
            }
          },
          error: function (e) {
            console.log(e);
          }
        });
      }
  
      function setInstanceNetwork() {
        $.ajax({
          async: false,
          type: "GET",
          url: "/api/neutron/networks/",
          contentType: "application/json;charset=UTF-8",
          success: function (response) {
            var networks = response.items;
            model.newInstanceSpec.networks.push({
              'id': networks[0].id
            });
            for (var network of networks) {
              if (network.router__external === false) {
                model.newInstanceSpec.networks[0].id = network.id;
                break;
              }
            }
          },
          error: function (e) {
            console.log(e);
          }
        });
      }
  
      return model;
    }
  
  })();
  